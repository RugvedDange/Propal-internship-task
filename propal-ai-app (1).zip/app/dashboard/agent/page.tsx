"use client"

import { useState, useEffect } from "react"
import { ChevronDown } from "lucide-react"

interface Language {
  name: string
  value: string
}

interface Model {
  name: string
  value: string
  languages: Language[]
}

interface Provider {
  name: string
  value: string
  models: Model[]
}

interface STTConfig {
  providers: Provider[]
}

export default function Agent() {
  const [config, setConfig] = useState<STTConfig | null>(null)
  const [selectedProvider, setSelectedProvider] = useState("")
  const [selectedModel, setSelectedModel] = useState("")
  const [selectedLanguage, setSelectedLanguage] = useState("")
  const [availableModels, setAvailableModels] = useState<Model[]>([])
  const [availableLanguages, setAvailableLanguages] = useState<Language[]>([])

  // Load config and saved selections
  useEffect(() => {
    const loadConfig = async () => {
      try {
        const response = await fetch("/stt.json")
        const data: STTConfig = await response.json()
        setConfig(data)

        // Load saved selections from localStorage
        const savedProvider = localStorage.getItem("selectedProvider")
        const savedModel = localStorage.getItem("selectedModel")
        const savedLanguage = localStorage.getItem("selectedLanguage")

        if (savedProvider) {
          setSelectedProvider(savedProvider)
          const provider = data.providers.find((p) => p.value === savedProvider)
          if (provider) {
            setAvailableModels(provider.models)

            if (savedModel) {
              setSelectedModel(savedModel)
              const model = provider.models.find((m) => m.value === savedModel)
              if (model) {
                setAvailableLanguages(model.languages)

                if (savedLanguage && model.languages.find((l) => l.value === savedLanguage)) {
                  setSelectedLanguage(savedLanguage)
                }
              }
            }
          }
        }
      } catch (error) {
        console.error("Failed to load STT config:", error)
      }
    }

    loadConfig()
  }, [])

  // Handle provider change
  const handleProviderChange = (providerValue: string) => {
    setSelectedProvider(providerValue)
    setSelectedModel("")
    setSelectedLanguage("")

    const provider = config?.providers.find((p) => p.value === providerValue)
    if (provider) {
      setAvailableModels(provider.models)
      setAvailableLanguages([])
    }

    // Save to localStorage
    localStorage.setItem("selectedProvider", providerValue)
    localStorage.removeItem("selectedModel")
    localStorage.removeItem("selectedLanguage")
  }

  // Handle model change
  const handleModelChange = (modelValue: string) => {
    setSelectedModel(modelValue)
    setSelectedLanguage("")

    const model = availableModels.find((m) => m.value === modelValue)
    if (model) {
      setAvailableLanguages(model.languages)
    }

    // Save to localStorage
    localStorage.setItem("selectedModel", modelValue)
    localStorage.removeItem("selectedLanguage")
  }

  // Handle language change
  const handleLanguageChange = (languageValue: string) => {
    setSelectedLanguage(languageValue)

    // Save to localStorage
    localStorage.setItem("selectedLanguage", languageValue)
  }

  // Get display names
  const getProviderName = () => config?.providers.find((p) => p.value === selectedProvider)?.name || ""
  const getModelName = () => availableModels.find((m) => m.value === selectedModel)?.name || ""
  const getLanguageName = () => availableLanguages.find((l) => l.value === selectedLanguage)?.name || ""

  if (!config) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-8">
      <div className="max-w-4xl">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Agent Configuration</h1>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 mb-8">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Speech-to-Text Settings</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Provider Dropdown */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Provider</label>
              <div className="relative">
                <select
                  value={selectedProvider}
                  onChange={(e) => handleProviderChange(e.target.value)}
                  className="w-full px-4 py-3 pr-10 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white appearance-none transition-colors"
                >
                  <option value="">Select Provider</option>
                  {config.providers.map((provider) => (
                    <option key={provider.value} value={provider.value}>
                      {provider.name}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400 pointer-events-none" />
              </div>
            </div>

            {/* Model Dropdown */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Model</label>
              <div className="relative">
                <select
                  value={selectedModel}
                  onChange={(e) => handleModelChange(e.target.value)}
                  disabled={!selectedProvider}
                  className="w-full px-4 py-3 pr-10 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white appearance-none transition-colors disabled:bg-gray-100 dark:disabled:bg-gray-600 disabled:cursor-not-allowed"
                >
                  <option value="">Select Model</option>
                  {availableModels.map((model) => (
                    <option key={model.value} value={model.value}>
                      {model.name}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400 pointer-events-none" />
              </div>
            </div>

            {/* Language Dropdown */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Language</label>
              <div className="relative">
                <select
                  value={selectedLanguage}
                  onChange={(e) => handleLanguageChange(e.target.value)}
                  disabled={!selectedModel}
                  className="w-full px-4 py-3 pr-10 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white appearance-none transition-colors disabled:bg-gray-100 dark:disabled:bg-gray-600 disabled:cursor-not-allowed"
                >
                  <option value="">Select Language</option>
                  {availableLanguages.map((language) => (
                    <option key={language.value} value={language.value}>
                      {language.name}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400 pointer-events-none" />
              </div>
            </div>
          </div>
        </div>

        {/* Summary Card */}
        {selectedProvider && selectedModel && selectedLanguage && (
          <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-xl p-6 transform transition-all duration-300 hover:shadow-md">
            <h3 className="text-lg font-semibold text-emerald-900 dark:text-emerald-100 mb-4">Configuration Summary</h3>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-emerald-800 dark:text-emerald-200">Provider:</span>
                <span className="text-sm text-emerald-900 dark:text-emerald-100">
                  {getProviderName()} ({selectedProvider})
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-emerald-800 dark:text-emerald-200">Model:</span>
                <span className="text-sm text-emerald-900 dark:text-emerald-100">
                  {getModelName()} ({selectedModel})
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-emerald-800 dark:text-emerald-200">Language:</span>
                <span className="text-sm text-emerald-900 dark:text-emerald-100">
                  {getLanguageName()} ({selectedLanguage})
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
