import { type NextRequest, NextResponse } from "next/server"
import { promises as fs } from "fs"
import path from "path"

interface User {
  id: string
  username: string
  email: string
  password: string
  phone?: string
}

export async function PUT(request: NextRequest) {
  try {
    const { id, email, password } = await request.json()

    // Validate required fields
    if (!id || !email) {
      return NextResponse.json({ error: "ID and email are required" }, { status: 400 })
    }

    // Read users file
    const filePath = path.join(process.cwd(), "public", "users.json")
    let users: User[] = []

    try {
      const fileContents = await fs.readFile(filePath, "utf8")
      users = JSON.parse(fileContents)
    } catch (error) {
      return NextResponse.json({ error: "No users found" }, { status: 404 })
    }

    // Find user index
    const userIndex = users.findIndex((u) => u.id === id)
    if (userIndex === -1) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Update user
    users[userIndex].email = email
    if (password) {
      users[userIndex].password = password // In production, hash this password!
    }

    // Save to file
    await fs.writeFile(filePath, JSON.stringify(users, null, 2))

    // Return updated user without password
    const { password: _, ...userWithoutPassword } = users[userIndex]

    return NextResponse.json({
      message: "Profile updated successfully",
      user: userWithoutPassword,
    })
  } catch (error) {
    console.error("Update profile error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
