import { type NextRequest, NextResponse } from "next/server"
import { promises as fs } from "fs"
import path from "path"
import { v4 as uuidv4 } from "uuid"

interface User {
  id: string
  username: string
  email: string
  password: string
  phone?: string
}

export async function POST(request: NextRequest) {
  try {
    const { username, email, password, phone } = await request.json()

    // Validate required fields
    if (!username || !email || !password) {
      return NextResponse.json({ error: "Username, email, and password are required" }, { status: 400 })
    }

    // Read existing users
    const filePath = path.join(process.cwd(), "public", "users.json")
    let users: User[] = []

    try {
      const fileContents = await fs.readFile(filePath, "utf8")
      users = JSON.parse(fileContents)
    } catch (error) {
      // File doesn't exist or is empty, start with empty array
      users = []
    }

    // Check if user already exists
    const existingUser = users.find((user) => user.email === email)
    if (existingUser) {
      return NextResponse.json({ error: "User with this email already exists" }, { status: 409 })
    }

    // Create new user
    const newUser: User = {
      id: uuidv4(),
      username,
      email,
      password, // In production, hash this password!
      phone: phone || undefined,
    }

    users.push(newUser)

    // Save to file
    await fs.writeFile(filePath, JSON.stringify(users, null, 2))

    // Return user without password
    const { password: _, ...userWithoutPassword } = newUser

    return NextResponse.json({
      message: "User created successfully",
      user: userWithoutPassword,
    })
  } catch (error) {
    console.error("Signup error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
